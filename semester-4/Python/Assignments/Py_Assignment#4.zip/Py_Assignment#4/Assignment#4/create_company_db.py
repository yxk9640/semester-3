
import sqlite3

def main():
    conn = sqlite3.connect('company.db')
    cur = conn.cursor()
    cur.execute('Drop Table if Exists Department')
    cur.execute('Drop Table if Exists Employee') 
    # Turn on the Foreign keys:
    cur.execute('PRAGMA foreign_keys= ON')
    # Create Table:
    cur.execute('''CREATE TABLE Department(DepartmentID INTEGER PRIMARY KEY NOT NULL,
                                            DepartmentName Text)''')
    cur.execute('''CREATE TABLE Employee(EmployeeID INTEGER PRIMARY KEY NOT NULL, 
                                                    EmployeeName TEXT,
                                                    DepartmentID INTEGER,
                                                    JoiningDate TEXT,
                                                    Salary REAL,
                                                    Experience INTEGER,
                                                    FOREIGN KEY(DepartmentID) REFERENCES Department(DepartmentID)
                                                    )''')
    # Insert data:
    cur.execute('''INSERT INTO Department(DepartmentID, DepartmentName) VALUES(1, 'IT'), (2, 'Marketing'), (3, 'HR'), (4, 'Sales')''')
    cur.execute('''INSERT INTO Employee(EmployeeID, EmployeeName, DepartmentID, JoiningDate, Salary, Experience)
                            VALUES (101, 'David', 1, '2005-2-10', 40000, 5),
                                    (102, 'Michael', 1, '2018-07-23', 20000, 2),
                                    (103, 'Susan', 2, '2016-05-19', 25000, 3),
                                    (104, 'Robert', 2, '2017-12-28', 28000, 7),
                                    (105, 'Linda', 3, '2004-06-04', 42000, 9),
                                    (106, 'William', 3, '2012-09-11', 30000, 5),
                                    (107, 'Richard', 4, '2014-08-21', 32000, 4),
                                    (108, 'Karen', 4, '2011-10-17', 30000, 8)''')
    
    conn.commit()
    conn.close()
