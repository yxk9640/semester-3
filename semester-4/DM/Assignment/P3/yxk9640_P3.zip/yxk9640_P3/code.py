import numpy as np
import pandas as pd
import random
import matplotlib.pyplot as plt
import sys


def run_kmeans(k):
    #check if file-name is passed
    if len(sys.argv) <= 1:
        print('Please provide a file name')
        sys.exit(1)
        
    #read the data set from the given file
    df = pd.read_csv(sys.argv[1], header=None, sep="\s+")
    
    #separate features/dimensions from the class lable
    features = df.drop(df.columns[-1], axis=1)
    columns = features.shape[1]
    
    #select k initial clusters randomly
    features['cluster_no'] = random.choices([i for i in range(k)], k=len(features))
    
    #calculate the initial centroids
    centroids = features.groupby('cluster_no').mean().values
    
    #reassign the points in the cluster for 20 iterations
    for iteration in range(20):
        
        #calculate the distance of points from the updated cluster
        for i in range(len(centroids)):
            diff_sum = ((features.iloc[:, :columns] - centroids[i]) ** 2).sum(axis=1)
            euc_dist = np.sqrt(diff_sum)

            features['c{}'.format(i)] = euc_dist


        features['nearest_no'] = features.loc[:, ['c{}'.format(i) for i in range(k)]].idxmin(axis=1)
        features['nearest_no'] = features['nearest_no'].map(lambda x: int(x.lstrip('c')))
        features['cluster_no'] = features['nearest_no']
        #calculate the new cluster centroids
        centroids = features.groupby('cluster_no').mean().iloc[:, :columns].values

    #calculate the SSE 
    return features.loc[:, ['c{}'.format(i) for i in range(k)]].min(axis=1).sum()


def display():
    y = []
    #perform the KMeans for different cluster numbers.
    for i in range(2, 11):
        y.append(run_kmeans(i))
        print('For k = {} After 20 iterations: SSE error = {:.4f}'.format(i, y[-1]))

    #plot the SSE error for each cluster adter 20 iterations
    _, img = plt.subplots()
    img.plot([i for i in range(2, 11)], y)
    plt.show() 
    
display()
